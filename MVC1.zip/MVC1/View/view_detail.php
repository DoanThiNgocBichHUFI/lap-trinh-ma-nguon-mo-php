<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Sach</title>
</head>
<body>
	
	<table>
		<tr>
			<td>ID</td>
			<td></td>
		</tr>
		<tr>
			<td>Name</td>
			<td><?php echo $data['book_name'] ?></td>
		</tr>
		<tr>
			<td>Hinh</td>
			<td></td>
		</tr>
		<tr>
			<td>Gia</td>
			<td></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
		</tr>
	</table>
</body>
</html>